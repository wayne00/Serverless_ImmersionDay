window._config = {
    api: {
        invokeUrl: 'https://8h73kg4yv9.execute-api.cn-north-1.amazonaws.com.cn/prod' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};
